# v5 手表大字体下翻版（手机端保持原样）

本版仅修改 `wear/src/main/java/com/supermarket/orderreminder/wear/WatchActivity.java` 的字体与行高，并将手表版本号升级至 32。手机端 `app/` 所有文件均与上传的 v4 一致；手机数据、每天新建的订货任务、手机提醒和双向同步代码完全不变。

- 手表任务仍按原顺序显示：`○/✓ + 订/事 + 名称`，单行排列、原有颜色与点击标记完成逻辑不变。
- 任务字号由动态 11–12sp 提升为 17sp；任务行高改为 34dp；日期、下方管理文字适度放大。
- 首页从原来强求显示 9 条改为优先保证文字清晰；超出屏幕可直接向下滑动，剩余任务在原顺序下方继续显示。
- 日期切换、同步、统计仍位于任务列表下方，操作及数据同步行为不变。
- **保留手机里已经建立的任务：不要卸载、重新安装或清除手机端数据。** 本次 GitHub Actions 只编译并上传手表端 APK。

## GitHub 一份 ZIP 编译

1. 新建空仓库，推荐名 `SupermarketOrderWatch8-LargeFont-v5`。
2. 在仓库根目录上传一份 `SupermarketOrderWatch8_LargerFont_v5_Source.zip`（无需解压）。
3. 在仓库创建 `.github/workflows/build-apk.yml`，复制本包同名工作流内容（本次同时单独提供该 YAML 文件）。
4. 进入 GitHub → Actions → `Build Watch8 Larger Font v5 (Phone Unchanged)` → Run workflow。
5. 下载 `OrderReminder-Watch8-LargerFont-v5`，解压得到 `wear-debug.apk`。**不编译、不安装手机版。**

注意：GitHub 新构建产生的 debug APK 不一定能覆盖旧版本（签名不同）。如果出现“应用未安装”，需要先核对旧版与新版签名；卸载手表端会清除手表的本地缓存和待回传记录，请先确认手机端已保存任务及手表已同步。**手机端签名与手表端签名不同时也可能影响 Wear OS Data Layer 通信**；需尽量使用与原手机 APK 一致的签名密钥来编译新版手表 APK。ZIP/APK 中不包含私钥，本版无法承诺直接覆盖安装或签名兼容。

本运行环境未提供 Android SDK/Gradle，故只完成源码修改及静态核验；APK 应由上面的 GitHub Actions 构建。

# 超市订货提醒 · 独立手机 App + Galaxy Watch 8（v3.0）

这是从用户提供的 `SupermarketOrderReminder_v1.9_Source.zip` 重制的**两款全新、独立安装**的 App，另带默认订货任务、旧版备份迁移和双向状态同步。旧版 v1.9 原样保留；本项目不能访问旧版应用的私人 SQLite 文件。

## 两端安装包及隔离

- **旧版**：`com.supermarket.orderreminder`。不要卸载，不覆盖，不改数据。
- **新版手机**：`com.supermarket.orderreminder.watch8plus`，名称「超市订货提醒·独立版」。保留旧版订货、事务、号码、备注、提醒、备份等手机功能；增加手表同步。
- **新版手表**：`com.supermarket.orderreminder.watch8plus`，名称「超市清单·Watch 8 独立版」。仅查看、标记完成、手动同步；**不支持新建或编辑**。
- 手机和手表应使用同一次编译产出的 APK，确保应用 ID 和签名证书一致。

## 旧版任务如何加入新手机 App

**无需备份即可看到默认清单**：新版独立 SQLite 在首次启动时预置旧版的周一至周六默认供应商订货（数据直接来自原 v1.9 源码），支持旧版同样的按需订货、事务提醒和完成记录。

**个性化历史任务必须通过 JSON 迁移**（源码/APK 不含你手机中编辑后的私人数据）：

1. 打开**旧版**手机 App → 展开「操作」→「设置」→「提醒设置与数据备份」→ **导出全部清单 / 联系人 / 完成记录（JSON）**，保存到手机文件夹。
2. 安装并打开**新版**手机 APK。首次启动会提示选择旧版备份；以后可以通过「操作」→ **导入旧版任务（JSON）**，或「设置」→「导入旧版任务 / 事务 / 完成记录」找到入口。
3. 选择旧版 JSON，先核对备份中**订货 / 事务 / 完成记录**条数，以及新版当前任务数，再点击「确认导入新版」。导入仅替换**新版**数据；原版不改。
4. 导入完成后显示备份任务数与新版实际任务数、备份完成数与新版实际完成数；核对无误再把新版当作主要手机端。
5. 在新版手机 App 添加/修改任务后自动发布到手表，手表完成操作会回传给新版。切勿继续同时编辑旧版和新版，否则两套数据库不会自动合并。

**重要：导入是覆盖新版本地数据而不是合并**。若你已在新版自行添加任务，导入前先从新版导出一份 JSON。数据库恢复在 SQLite 事务中执行，备份校验或数据库插入失败会回滚。

## GitHub Actions（无需自己安装编译软件）

1. 新建空仓库，推荐名称 `SupermarketOrderWatch8-Independent`。
2. 在仓库根目录上传 `SupermarketOrderWatch8_Independent_v3_Source.zip` 一份即可，不用解压。
3. 创建 `.github/workflows/build-apk.yml`，内容使用随附的 `SupermarketOrderWatch8_Independent_v3_build-apk.yml`。
4. GitHub Actions → `Build Watch8 Compact 9 Rows (Phone Unchanged)` → Run workflow。
5. 下载分别命名为 `OrderReminder-Phone-Unchanged-v3` 与 `OrderReminder-Watch8-Compact9-v4` 的 Artifacts。
6. 解压取得手机 `app-debug.apk` 和手表 `wear-debug.apk` 并分别安装。

你也可以解压源码 ZIP 并上传文件夹和内置的 `.github/workflows/build-apk.yml`，两种方式选其一。GitHub debug 签名可能随构建变化，后续更新前请先导出新版 JSON；正式长期使用建议配置固定签名。

## 状态及限制

- 已进行源文件、Manifest、文件清单、包名一致性和迁移逻辑的静态检查；**没有 Android SDK/Gradle 与 Watch 8 真机环境**，故尚不能声称已编译或实机验证可用。
- 手表断连时可看上次缓存的清单并记录待同步完成项；恢复连接后重试。**未收到手机 ACK 不能认为已写回成功**。
- Data Layer 不需要自行搭服务器，但取决于 Galaxy Watch 8 配对、Google Play services 和后台连接状态。
- 手机端是唯一主数据库；不会直接读取旧版私人应用数据。
