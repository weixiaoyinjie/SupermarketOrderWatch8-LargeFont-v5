package com.supermarket.orderreminder.wear;

import android.content.Intent;
import android.util.Log;

import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.WearableListenerService;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;

/** Receives updates while the UI is closed; cached days remain usable offline. */
public class WatchSyncService extends WearableListenerService {
    static void accept(android.content.Context c, DataItem dataItem) {
        String path = dataItem.getUri().getPath();
        if (path == null || !path.startsWith(WatchStore.PATH_DAY)) return;
        try {
            String date = path.substring(WatchStore.PATH_DAY.length());
            com.google.android.gms.wearable.DataMap map = DataMapItem.fromDataItem(dataItem).getDataMap();
            WatchStore.storeSnapshot(c, date, map.getString("json", ""), map.getLong("sent_at"));
        } catch (Exception e) { Log.e("OrderWatch", "数据解析失败", e); }
    }

    @Override public void onDataChanged(DataEventBuffer events) {
        for (DataEvent e : events) {
            if (e.getType() == DataEvent.TYPE_CHANGED) accept(this, e.getDataItem());
        }
        WatchLink.flush(this); // Retry persisted, unacknowledged completion operations.
        announce();
    }
    @Override public void onPeerConnected(com.google.android.gms.wearable.Node peer) {
        // Best effort when watch reconnects to paired phone.
        WatchLink.flush(this);
    }
    @Override public void onMessageReceived(MessageEvent message) {
        if (!WatchStore.PATH_ACK.equals(message.getPath())) return;
        try {
            JSONObject ack = new JSONObject(new String(message.getData(), StandardCharsets.UTF_8));
            WatchStore.ack(this, ack);
            WatchLink.flush(this);
            announce();
        } catch (Exception e) { Log.e("OrderWatch", "ACK 解析失败", e); }
    }
    private void announce() {
        Intent update = new Intent(WatchStore.BROADCAST_UPDATED);
        update.setPackage(getPackageName());
        sendBroadcast(update);
    }
}
