package com.supermarket.orderreminder.wear;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.util.UUID;

/** Local offline cache + durable completion outbox. No SQLite or reset-on-launch. */
public final class WatchStore {
    static final String PATH_DAY = "/orders/day/";
    static final String PATH_REQUEST = "/orders/request";
    static final String PATH_SET_DONE = "/orders/set_done";
    static final String PATH_ACK = "/orders/ack";
    static final String BROADCAST_UPDATED = "com.supermarket.orderreminder.watch8plus.WATCH_UPDATED";

    private WatchStore() { }
    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("order_wear_cache", Context.MODE_PRIVATE);
    }
    private static JSONArray pending(Context c) {
        try { return new JSONArray(prefs(c).getString("pending", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }
    static synchronized JSONArray getPending(Context c) { return pending(c); }
    static synchronized boolean hasPending(Context c, long id, String due) {
        JSONArray list = pending(c);
        for (int i = 0; i < list.length(); i++) {
            JSONObject o = list.optJSONObject(i);
            if (o != null && o.optLong("id") == id && due.equals(o.optString("date"))) return true;
        }
        return false;
    }
    static synchronized boolean done(Context c, JSONObject row) {
        long id = row.optLong("id");
        String due = row.optString("due");
        JSONArray list = pending(c);
        for (int i = list.length() - 1; i >= 0; i--) {
            JSONObject o = list.optJSONObject(i);
            if (o != null && o.optLong("id") == id && due.equals(o.optString("date")))
                return o.optBoolean("done");
        }
        // Preserve visual confirmation until an updated snapshot arrives.
        try {
            JSONObject a = new JSONObject(prefs(c).getString("acked", "{}"));
            JSONObject o = a.optJSONObject(id + "@" + due);
            if (o != null) return o.optBoolean("done");
        } catch (Exception ignored) { }
        return row.optBoolean("done");
    }
    static synchronized void queue(Context c, long id, String due, boolean checked) {
        try {
            if (hasPending(c, id, due)) return;
            JSONObject op = new JSONObject();
            op.put("id", id); op.put("date", due); op.put("done", checked);
            op.put("op", UUID.randomUUID().toString());
            JSONArray list = pending(c);
            list.put(op);
            prefs(c).edit().putString("pending", list.toString()).commit();
        } catch (Exception ignored) { }
    }
    static synchronized void ack(Context c, JSONObject confirmation) {
        String opId = confirmation.optString("op");
        if (opId.isEmpty()) return;
        JSONArray remaining = new JSONArray();
        JSONArray list = pending(c);
        boolean found = false;
        for (int i = 0; i < list.length(); i++) {
            JSONObject op = list.optJSONObject(i);
            if (op == null) continue;
            if (opId.equals(op.optString("op"))) { found = true; continue; }
            remaining.put(op);
        }
        if (!found) return;
        try {
            JSONObject acked = new JSONObject(prefs(c).getString("acked", "{}"));
            String key = confirmation.optLong("id") + "@" + confirmation.optString("date");
            acked.put(key, confirmation);
            prefs(c).edit().putString("pending", remaining.toString())
                    .putString("acked", acked.toString()).apply();
        } catch (Exception ignored) { }
    }
    static synchronized void storeSnapshot(Context c, String date, String raw, long stamped) {
        try {
            if (!LocalDate.parse(date).toString().equals(date)) return;
            JSONObject j = new JSONObject(raw);
            if (j.optInt("schema") != 1 || !date.equals(j.optString("date"))) return;
            if (j.optJSONArray("orders") == null || j.optJSONArray("tasks") == null) return;
            SharedPreferences p = prefs(c);
            if (stamped < p.getLong("time_" + date, -1)) return;
            JSONObject acked = new JSONObject(p.getString("acked", "{}"));
            for (String field : new String[]{"orders", "tasks"}) {
                JSONArray array = j.getJSONArray(field);
                for (int i = 0; i < array.length(); i++) {
                    JSONObject row = array.optJSONObject(i);
                    if (row == null) continue;
                    String key = row.optLong("id") + "@" + row.optString("due");
                    JSONObject ack = acked.optJSONObject(key);
                    // A newer phone snapshot is authoritative, including an undo performed on phone.
                    if (ack != null) acked.remove(key);
                }
            }
            p.edit().putString("snapshot_" + date, raw)
                    .putLong("time_" + date, stamped)
                    .putString("acked", acked.toString()).apply();
        } catch (Exception ignored) { }
    }
    static synchronized JSONObject getSnapshot(Context c, String date) {
        try { return new JSONObject(prefs(c).getString("snapshot_" + date, "")); }
        catch (Exception ignored) { return null; }
    }
    static long receivedAt(Context c, String date) { return prefs(c).getLong("time_" + date, 0); }
    static synchronized int pendingCount(Context c) { return pending(c).length(); }
}
