package com.supermarket.orderreminder;

import android.util.Log;
import android.content.Intent;

import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.Wearable;
import com.google.android.gms.wearable.WearableListenerService;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/** Receives Wear OS completion; saves directly to the new full phone app's database. */
public final class PhoneSyncService extends WearableListenerService {
    private static final String TAG = "OrderPhoneSync";

    @Override public void onMessageReceived(MessageEvent event) {
        String path = event.getPath();
        if (!SyncPublisher.PATH_REQUEST.equals(path) && !SyncPublisher.PATH_SET_DONE.equals(path)) return;
        try {
            if (event.getData() == null || event.getData().length > 8192) return;
            JSONObject request = new JSONObject(new String(event.getData(), StandardCharsets.UTF_8));
            String due = request.getString("date");
            LocalDate selected = LocalDate.parse(due);
            if (Math.abs(ChronoUnit.DAYS.between(LocalDate.now(), selected)) > 370) return;
            if (SyncPublisher.PATH_REQUEST.equals(path)) {
                SyncPublisher.publishOne(this, selected, true);
                return;
            }
            if (!request.getBoolean("done")) return; // Watch can only mark complete.
            long id = request.getLong("id");
            String opId = request.getString("op");
            if (id <= 0 || opId.length() < 8 || opId.length() > 100) return;

            try (Db db = new Db(this)) {
                Entry found = null;
                // Only an occurrence actually exposed to the watch may be changed.
                for (Entry entry : db.forDate(selected)) {
                    if (entry.id == id && entry.kind == 0 && entry.repeatType != 3) {
                        found = entry;
                        break;
                    }
                }
                if (found == null) {
                    for (Db.TaskOccurrence occurrence : db.tasksForDate(selected)) {
                        if (occurrence.entry.id == id && due.equals(occurrence.dueDate.toString())) {
                            found = occurrence.entry;
                            break;
                        }
                    }
                }
                // Overdue tasks can be shown on a later day's list: the watch
                // sends the occurrence due date, which is <= today. Validate separately.
                if (found == null) {
                    Entry e = db.getEntry(id);
                    if (e != null && e.kind == 1 && !selected.isAfter(LocalDate.now())) {
                        for (Db.TaskOccurrence occ : db.tasksForDate(LocalDate.now())) {
                            if (occ.entry.id == id && due.equals(occ.dueDate.toString())) {
                                found = e;
                                break;
                            }
                        }
                    }
                }
                if (found == null) return;
                String completedOn = LocalDate.now().toString();
                db.setDone(id, due, true, completedOn);
            }
            JSONObject ack = new JSONObject();
            ack.put("op", opId);
            ack.put("id", id);
            ack.put("date", due);
            ack.put("done", true);
            Wearable.getMessageClient(this).sendMessage(event.getSourceNodeId(),
                    SyncPublisher.PATH_ACK, ack.toString().getBytes(StandardCharsets.UTF_8))
                    .addOnFailureListener(error -> Log.w(TAG, "ACK send failed", error));
            SyncPublisher.schedule(this);
            SyncPublisher.publishOne(this, selected, true);
            Intent changed = new Intent(MainActivity.ACTION_WATCH_UPDATED);
            changed.setPackage(getPackageName());
            sendBroadcast(changed);
        } catch (Exception error) { Log.e(TAG, "Watch message error", error); }
    }
}
